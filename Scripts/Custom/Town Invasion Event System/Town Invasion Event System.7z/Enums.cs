﻿using System;

namespace Server.EventSystem
{
	public enum EventType
	{
		None,
		TownInvasion
	}
}