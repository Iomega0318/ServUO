﻿using System;

namespace Server.EventSystem
{
	public enum TownMonsterType
	{
		Abyss,
		Arachnid,
		DragonKind,
		Elementals,
		Humanoid,
		OrcsandRatmen,
		OreElementals,
		Ophidian,
		Snakes,
		Undead
	}

	public enum TownChampionType
	{
		Barracoon,
		Harrower,
		LordOaks,
		Mephitis,
		Neira,
		Rikktor,
		Semidar,
		Serado
	}
}