using System;
using System.Collections;
using Server;
using Server.ACC.CM;

namespace Server.ACC.CSS.Modules
{
	public class IconsModule : Module
	{
		private Hashtable m_Icons;
		public Hashtable Icons{ get{ return m_Icons; } }

		public override string Name(){ return "Spell Icons"; }

		public IconsModule( Serial serial ) : this( serial, null )
		{
		}

		public IconsModule( Serial serial, IconInfo info ) : base( serial )
		{
			m_Icons = new Hashtable();

			Add( info );
		}

		public void Add( IconInfo info )
		{
			if( info == null )
				return;

			if( m_Icons.ContainsKey( info.SpellType ) )
				m_Icons[ info.SpellType ] = info;

			else
				m_Icons.Add( info.SpellType, info );
		}

		public IconInfo Get( Type type )
		{
			return (IconInfo)m_Icons[ type ];
		}

		public bool Contains( Type type )
		{
			return m_Icons.ContainsKey( type );
		}

		public void Remove( Type type )
		{
			m_Icons.Remove( type );

			if( m_Icons.Count == 0 )
				CentralMemory.RemoveModule( this.Owner, (Module)this );
		}

		public override void Append( Module mod, bool negatively )
		{
			IconsModule im = mod as IconsModule;
			ArrayList rem = new ArrayList();

			foreach( DictionaryEntry de in im.Icons )
			{
				if( negatively )
					rem.Add( ((IconInfo)de.Value).SpellType );
				else
					Add( (IconInfo)de.Value );
			}

			foreach( Type t in rem )
			{
				Remove( t );
			}
			rem.Clear();
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int)1 ); // version

			writer.Write( m_Icons.Count );
			foreach( DictionaryEntry de in m_Icons )
			{
				((IconInfo)de.Value).Serialize( writer );
			}
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();

			m_Icons = new Hashtable();

			int count = reader.ReadInt();
			for( int i = 0; i < count; i++ )
			{
				IconInfo ii = new IconInfo( reader );
				if( ii.SpellType != null )
					m_Icons.Add( ii.SpellType, ii );
			}
		}
	}
}