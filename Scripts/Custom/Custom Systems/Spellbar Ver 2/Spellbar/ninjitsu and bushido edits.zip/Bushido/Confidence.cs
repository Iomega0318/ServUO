using System;
using System.Collections;
using Server.Items;
using Server.Gumps;
using Server.Engines.XmlSpawner2;

namespace Server.Spells.Bushido
{
    public class Confidence : SamuraiSpell
    {
			/// added ///
		public SpellBarScroll m_Scroll; 
	/// end added ///
	
        private static readonly SpellInfo m_Info = new SpellInfo(
            "Confidence", null,
            -1,
            9002);
        private static readonly Hashtable m_Table = new Hashtable();
        private static readonly Hashtable m_RegenTable = new Hashtable();
        public Confidence(Mobile caster, Item scroll)
            : base(caster, scroll, m_Info)
        {
        }

        public override TimeSpan CastDelayBase
        {
            get
            {
                return TimeSpan.FromSeconds(0.25);
            }
        }
        public override double RequiredSkill
        {
            get
            {
                return 25.0;
            }
        }
        public override int RequiredMana
        {
            get
            {
                return 10;
            }
        }
        public static bool IsConfident(Mobile m)
        {
            return m_Table.Contains(m);
        }

        public static void BeginConfidence(Mobile m)
        {
            Timer t = (Timer)m_Table[m];

            if (t != null)
                t.Stop();

            t = new InternalTimer(m);

            m_Table[m] = t;

            t.Start();
			
			//Item scroll = (Item)(m.Backpack.FindItemByType(typeof(SpellBarScroll)));

			//SpellBarScroll m_Scroll = (SpellBarScroll) scroll ; 
			
			SpellBarScroll scroll = (SpellBarScroll)XmlAttach.FindAttachment(m, typeof(SpellBarScroll));
				
		//m_Scroll.mCountering  = 0;
			
			if ( m.HasGump(typeof (SpellBarGump.SpellBar_BarGump)) )
			{
				m.CloseGump( typeof( SpellBarGump.SpellBar_BarGump ) );
					
				int dbx = 0; int dbxa = 0; int dby = 0; int dbya = 0; int xselect_var = 0;
				
					
				m.SendGump(new SpellBarGump.SpellBar_BarGump(m,  scroll, scroll.Xo, scroll.Yo ));
			}
			
			/// end added ///
        }

        public static void EndConfidence(Mobile m)
        {
            Timer t = (Timer)m_Table[m];

            if (t != null)
                t.Stop();

            m_Table.Remove(m);

            OnEffectEnd(m, typeof(Confidence));
			
			/// added ///
			
			//Item scroll = (Item)(m.Backpack.FindItemByType(typeof(SpellBarScroll)));

			//SpellBarScroll m_Scroll = (SpellBarScroll) scroll ; 
			
		//m_Scroll.mCountering  = 0;
		
		SpellBarScroll scroll = (SpellBarScroll)XmlAttach.FindAttachment(m, typeof(SpellBarScroll));
			
			if ( m.HasGump(typeof (SpellBarGump.SpellBar_BarGump)) )
			{
				m.CloseGump( typeof( SpellBarGump.SpellBar_BarGump ) );
					
				int dbx = 0; int dbxa = 0; int dby = 0; int dbya = 0; int xselect_var = 0;
					
				m.SendGump(new SpellBarGump.SpellBar_BarGump(m,  scroll, scroll.Xo, scroll.Yo ));
			}
			
			/// end added ///
			
        }

        public static bool IsRegenerating(Mobile m)
        {
            return m_RegenTable.Contains(m);
        }

        public static void BeginRegenerating(Mobile m)
        {
            Timer t = (Timer)m_RegenTable[m];

            if (t != null)
                t.Stop();

            t = new RegenTimer(m);

            m_RegenTable[m] = t;

            t.Start();
        }

        public static void StopRegenerating(Mobile m)
        {
            Timer t = (Timer)m_RegenTable[m];

            if (t != null)
                t.Stop();

            m_RegenTable.Remove(m);
        }

        public override void OnBeginCast()
        {
            base.OnBeginCast();

            this.Caster.FixedEffect(0x37C4, 10, 7, 4, 3);
        }

        public override void OnCast()
        {
            if (this.CheckSequence())
            {
                this.Caster.SendLocalizedMessage(1063115); // You exude confidence.

                this.Caster.FixedParticles(0x375A, 1, 17, 0x7DA, 0x960, 0x3, EffectLayer.Waist);
                this.Caster.PlaySound(0x51A);

                this.OnCastSuccessful(this.Caster);

                BeginConfidence(this.Caster);
                BeginRegenerating(this.Caster);
            }

            this.FinishSequence();
        }

        private class InternalTimer : Timer
        {
            private readonly Mobile m_Mobile;
            public InternalTimer(Mobile m)
                : base(TimeSpan.FromSeconds(15.0))
            {
                this.m_Mobile = m;
                this.Priority = TimerPriority.TwoFiftyMS;
            }

            protected override void OnTick()
            {
                EndConfidence(this.m_Mobile);
                this.m_Mobile.SendLocalizedMessage(1063116); // Your confidence wanes.
            }
        }

        private class RegenTimer : Timer
        {
            private readonly Mobile m_Mobile;
            private readonly int m_Hits;
            private int m_Ticks;
            public RegenTimer(Mobile m)
                : base(TimeSpan.FromSeconds(1.0), TimeSpan.FromSeconds(1.0))
            {
                this.m_Mobile = m;
                this.m_Hits = 15 + (m.Skills.Bushido.Fixed * m.Skills.Bushido.Fixed / 57600);
                this.Priority = TimerPriority.TwoFiftyMS;
            }

            protected override void OnTick()
            {
                ++this.m_Ticks;

                if (this.m_Ticks >= 5)
                {
                    this.m_Mobile.Hits += (this.m_Hits - (this.m_Hits * 4 / 5));
                    StopRegenerating(this.m_Mobile);
                }

                this.m_Mobile.Hits += (this.m_Hits / 5);
            }
        }
    }
}