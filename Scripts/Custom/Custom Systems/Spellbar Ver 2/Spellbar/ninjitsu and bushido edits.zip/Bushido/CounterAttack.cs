using System;
using System.Collections;
using Server.Items;
using Server.Gumps;
using Server.Engines.XmlSpawner2;

namespace Server.Spells.Bushido
{
    public class CounterAttack : SamuraiSpell
    {
		/// added ///
		public SpellBarScroll m_Scroll; 
	/// end added ///
	
	
        private static readonly SpellInfo m_Info = new SpellInfo(
            "CounterAttack", null,
            -1,
            9002);
        private static readonly Hashtable m_Table = new Hashtable();
        public CounterAttack(Mobile caster, Item scroll)
            : base(caster, scroll, m_Info)
        {
        }

        public override TimeSpan CastDelayBase
        {
            get
            {
                return TimeSpan.FromSeconds(0.25);
            }
        }
        public override double RequiredSkill
        {
            get
            {
                return 40.0;
            }
        }
        public override int RequiredMana
        {
            get
            {
                return 5;
            }
        }
        public static bool IsCountering(Mobile m)
        {
            return m_Table.Contains(m);
        }

        public static void StartCountering(Mobile m)
        {
            Timer t = (Timer)m_Table[m];

            if (t != null)
                t.Stop();

            t = new InternalTimer(m);

            m_Table[m] = t;

            t.Start();
			
		//	Item scroll = (Item)(m.Backpack.FindItemByType(typeof(SpellBarScroll)));

			//SpellBarScroll m_Scroll = (SpellBarScroll) scroll ; 
			SpellBarScroll scroll = (SpellBarScroll)XmlAttach.FindAttachment(m, typeof(SpellBarScroll));
				
		//m_Scroll.mCountering  = 0;
			
			if ( m.HasGump(typeof (SpellBarGump.SpellBar_BarGump)) )
			{
				m.CloseGump( typeof( SpellBarGump.SpellBar_BarGump ) );
					
				int dbx = 0; int dbxa = 0; int dby = 0; int dbya = 0; int xselect_var = 0;
				
					
				m.SendGump(new SpellBarGump.SpellBar_BarGump(m,  scroll, scroll.Xo, scroll.Yo ));
			}
			
			/// end added ///
			
			//m_Scroll.mCountering  = 1;
        }

        public static void StopCountering(Mobile m)
        {
            Timer t = (Timer)m_Table[m];

            if (t != null)
                t.Stop();

            m_Table.Remove(m);

            OnEffectEnd(m, typeof(CounterAttack));
			
			
			
			/// added ///
			
			//Item scroll = (Item)(m.Backpack.FindItemByType(typeof(SpellBarScroll)));

			//SpellBarScroll m_Scroll = (SpellBarScroll) scroll ; 
			SpellBarScroll scroll = (SpellBarScroll)XmlAttach.FindAttachment(m, typeof(SpellBarScroll));
		//m_Scroll.mCountering  = 0;
			
			if ( m.HasGump(typeof (SpellBarGump.SpellBar_BarGump)) )
			{
				m.CloseGump( typeof( SpellBarGump.SpellBar_BarGump ) );
					
				int dbx = 0; int dbxa = 0; int dby = 0; int dbya = 0; int xselect_var = 0;
					
				m.SendGump(new SpellBarGump.SpellBar_BarGump(m,  scroll, scroll.Xo, scroll.Yo ));
			}
			
			/// end added ///
        }

        public override bool CheckCast()
        {
            if (!base.CheckCast())
                return false;

            if (this.Caster.FindItemOnLayer(Layer.TwoHanded) as BaseShield != null)
                return true;

            if (this.Caster.FindItemOnLayer(Layer.OneHanded) as BaseWeapon != null)
                return true;

            if (this.Caster.FindItemOnLayer(Layer.TwoHanded) as BaseWeapon != null)
                return true;

            this.Caster.SendLocalizedMessage(1062944); // You must have a weapon or a shield equipped to use this ability!
            return false;
        }

        public override void OnBeginCast()
        {
            base.OnBeginCast();

            this.Caster.FixedEffect(0x37C4, 10, 7, 4, 3);
        }

        public override void OnCast()
        {
            if (this.CheckSequence())
            {
                this.Caster.SendLocalizedMessage(1063118); // You prepare to respond immediately to the next blocked blow.

                this.OnCastSuccessful(this.Caster);

                StartCountering(this.Caster);
            }

            this.FinishSequence();
        }

        private class InternalTimer : Timer
        {
            private readonly Mobile m_Mobile;
            public InternalTimer(Mobile m)
                : base(TimeSpan.FromSeconds(30.0))
            {
                this.m_Mobile = m;
                this.Priority = TimerPriority.TwoFiftyMS;
            }

            protected override void OnTick()
            {
                StopCountering(this.m_Mobile);
                this.m_Mobile.SendLocalizedMessage(1063119); // You return to your normal stance.
            }
        }
    }
}