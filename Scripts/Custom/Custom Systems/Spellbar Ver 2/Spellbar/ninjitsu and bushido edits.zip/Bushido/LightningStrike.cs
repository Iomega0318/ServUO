using System;
using Server.Mobiles;
using Server.Items;
using Server.Gumps;
using Server.Engines.XmlSpawner2;

namespace Server.Spells.Bushido
{
    public class LightningStrike : SamuraiMove
    {
	
	/// added ///
		public SpellBarScroll m_Scroll; 
	/// end added ///
	
        public LightningStrike()
        {
        }

        public override int BaseMana
        {
            get
            {
                return 5;
            }
        }
        public override double RequiredSkill
        {
            get
            {
                return 50.0;
            }
        }
        public override TextDefinition AbilityMessage
        {
            get
            {
                return new TextDefinition(1063167);
            }
        }// You prepare to strike quickly.
        public override bool DelayedContext
        {
            get
            {
                return true;
            }
        }
        public override bool ValidatesDuringHit
        {
            get
            {
                return false;
            }
        }
        public override int GetAccuracyBonus(Mobile attacker)
        {
            return 50;
        }

        public override bool Validate(Mobile from)
        {
            bool isValid = base.Validate(from);
            if (isValid)
            {
                PlayerMobile ThePlayer = from as PlayerMobile;
                ThePlayer.ExecutesLightningStrike = this.BaseMana;
            }
            return isValid;
        }

        public override bool IgnoreArmor(Mobile attacker)
        {
            double bushido = attacker.Skills[SkillName.Bushido].Value;
            double criticalChance = (bushido * bushido) / 72000.0;
            return (criticalChance >= Utility.RandomDouble());
        }

        public override bool OnBeforeSwing(Mobile attacker, Mobile defender)
        {
            /* no mana drain before actual hit */
            bool enoughMana = this.CheckMana(attacker, false);
            return this.Validate(attacker);
        }

        public override void OnHit(Mobile attacker, Mobile defender, int damage)
        {
            ClearCurrentMove(attacker);
			
			/// added ///
			
		//	Item scroll = (Item)(attacker.Backpack.FindItemByType(typeof(SpellBarScroll)));

			//SpellBarScroll m_Scroll = (SpellBarScroll) scroll ; 
			
			SpellBarScroll scroll = (SpellBarScroll)XmlAttach.FindAttachment(attacker, typeof(SpellBarScroll));
			
			if ( attacker.HasGump(typeof (SpellBarGump.SpellBar_BarGump)) )
			{
				attacker.CloseGump( typeof( SpellBarGump.SpellBar_BarGump ) );
					
				int dbx = 0; int dbxa = 0; int dby = 0; int dbya = 0; int xselect_var = 0;
					
				attacker.SendGump(new SpellBarGump.SpellBar_BarGump(attacker, scroll, scroll.Xo, scroll.Yo));
			}
			
			/// end added ///
			
			
            if (this.CheckMana(attacker, true))
            {
                attacker.SendLocalizedMessage(1063168); // You attack with lightning precision!
                defender.SendLocalizedMessage(1063169); // Your opponent's quick strike causes extra damage!
                defender.FixedParticles(0x3818, 1, 11, 0x13A8, 0, 0, EffectLayer.Waist);
                defender.PlaySound(0x51D);
                this.CheckGain(attacker);
                this.SetContext(attacker);
            }
        }

        public override void OnClearMove(Mobile attacker)
        {
            PlayerMobile ThePlayer = attacker as PlayerMobile; // this can be deletet if the PlayerMobile parts are moved to Server.Mobile 
            ThePlayer.ExecutesLightningStrike = 0;
        }
    }
}