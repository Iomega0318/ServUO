Mythik Achievement System
=========================

### Installation


Installation should be as simple as drop it in your custom scripts folder.

The script will self generate a stone to store achievment data on, unless you 
remove the #define STOREONITEM, and make the edits required to your PlayerMobile.


### Adding Achievments

Currently there are Hunter, Resource gathering, and Region discovery achievment types.

You must edit the AchievmentSystem.cs file there are comments and example entries included.

Once you have the system running do not change Achievment ID's as progress is stored tied to the ID not the actual achievment.



### Coming Soon

1. Loading Achievments and Categories from JSON and/or XML
2. Standalone editor for above mentioned JSON / XML files.
3. More achievment types, Skill gain based( core mods), craft based ( core mods )
4. Community feedback and input.

